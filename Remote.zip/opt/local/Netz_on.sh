#!/bin/bash
cd /sys/class/gpio/

echo "2" > /sys/class/gpio/unexport


if [ -e /sys/class/gpio/export ]
then
echo "2" > /sys/class/gpio/export
fi
echo out > /sys/class/gpio/gpio2/direction
echo 1 > /sys/class/gpio/gpio2/value
