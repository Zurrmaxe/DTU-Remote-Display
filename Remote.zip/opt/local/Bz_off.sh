#!/bin/bash
cd /sys/class/gpio/
echo "3" > /sys/class/gpio/unexport


if [ -e /sys/class/gpio/export ]
then
echo "3" > /sys/class/gpio/export
fi
echo out > /sys/class/gpio/gpio3/direction
echo 0 > /sys/class/gpio/gpio3/value

