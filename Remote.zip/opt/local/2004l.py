#!/usr/bin/env python
# -*- coding: utf-8 -*-
# DK1AW 2022 lcdsvx

import time
from datetime import datetime
import locale
#locale.setlocale(locale.LC_ALL, 'de_DE.utf8')

import math
import os
import RPLCD
import subprocess
from RPLCD import *
from time import sleep
from RPLCD.i2c import CharLCD

lcd = CharLCD(i2c_expander='PCF8574', address=0x27, port=0,
              cols=20, rows=4, dotsize=10,
              charmap='A02',
              auto_linebreaks=False)

def get_ip():
    cmd = "hostname -I | awk '{print $1}'"
    IP = subprocess.check_output(cmd, shell = True ).decode("utf-8")
    return "IP:" + str(IP).rstrip("\r\n")+" "

def get_temp():
    # get cpu temperature
    try:
        with open("/sys/class/thermal/thermal_zone0/temp", "r") as temp:
            tmpCel = int(temp.read()[:2])
    except:
        tmpCel = 0
    finally:
        return "T:"+str(tmpCel)+"C"

def get_cpuL():
    cmd = "top -bn1 | grep load | awk '{printf \" CPU:L %.2f\", $(NF-2)}'"
    CPUL = subprocess.check_output(cmd, shell = True ).decode("utf-8")
    return CPUL


def get_svxlog():
    f = os.popen('egrep -a -h "Talker start on|Talker stop on" /var/log/svxlink | tail -1')
    logsvx = str(f.read()).split(" ")
    if len(logsvx)>=2 and logsvx[4]=="start":
       CALL=logsvx[8].rstrip("\r\n")
       TalkG="TG "+logsvx[7].lstrip("#").rstrip(":")
    else:
       CALL=""
       TalkG=""
    return CALL,TalkG

while 1:


    check_svx=get_svxlog()
    lcd.cursor_pos = (0,0)
    msga = get_ip()
    lcd.write_string(msga)

    lcd.cursor_pos = (1,3)
    msgd = str(check_svx[1])
    lcd.write_string(msgd)

    lcd.cursor_pos = (2,3)
    msge = str(check_svx[0])
    lcd.write_string(msge)

    lcd.cursor_pos = (3,0)
    msgb = get_temp()
    lcd.write_string(msgb)

    lcd.cursor_pos = (3,7)
    msgc = get_cpuL()
    lcd.write_string(msgc)


    #lcd.cursor_pos = (3,0)
    #msgob = svx_link()
    #lcd.write_string(msgob)


    #current_time = now.strftime("%a %H:%M:%S")
    #msgt = str(current_time)
    #lcd.cursor_pos = (3,0)
    #lcd.write_string(msgt)

lcd.clear()

